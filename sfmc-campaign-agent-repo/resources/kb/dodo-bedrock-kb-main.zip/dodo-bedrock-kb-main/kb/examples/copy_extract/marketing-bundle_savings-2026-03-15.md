# Approved EDM (Copy Extract)

**comm_type:** marketing
**campaign_type:** offer
**product:** energy
**audience_stage:** active
**date_sent:** 2026-03-15
**source:** sanitised internal HTML example

## Subject
More services. More savings

## Preheader
More services. More savings

## Body (rendered text; NO PII)
Hey <FIRSTNAME>

We’re always looking for ways to give you more value from your internet.

Did you know that you can save even more by bundling?

Check out our home bundle package.

Internet + Power & Gas = save up to <AMOUNT>/year
Enjoy competitive rates with Dodo’s energy plans.

And the best part? It’s easy. Just sign up for a Dodo energy plan and the discount is automatically applied to your nbn bill.

CTA: VIEW BUNDLE

Need a hand? We’re just a click away.

## Notes (optional)
- CTA label: VIEW BUNDLE
- Offer / key details: Bundle discount applied after energy activation
- Compliance notes: Offer terms required
