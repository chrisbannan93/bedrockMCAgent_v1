# Approved EDM (Copy Extract)

**comm_type:** marketing
**campaign_type:** offer
**product:** internet
**audience_stage:** active
**date_sent:** 2026-03-01
**source:** sanitised internal HTML example

## Subject
Upgrade to fibre for faster speeds

## Preheader
Upgrade to fibre today and enjoy faster internet speeds

## Body (rendered text; NO PII)
Hey <FIRSTNAME>

The way we live, work and chill at home is becoming more dependent on having the best and most up-to-date technology.

Movies drop online first, meetings happen in the lounge room, and the kids are learning and playing from their bedrooms.

Now it’s your turn to get ahead.

Your home is eligible for a fibre upgrade that can deliver speeds up to 10x faster than what you’ve got today for just $<AMOUNT> more per month.

Your current Dodo modem won’t reach the potential of these new speeds, but our high-speed Family Modem is ready to go for just $<AMOUNT> a month for 24 months or $<AMOUNT> upfront, so you can stream, work, and play without limits.

Ready to upgrade to fibre and get a high-speed compatible Dodo modem?
Call <PHONE> (press 1) or chat with our team at <LINK> and we’ll organise everything for you.

## Notes (optional)
- CTA label: None
- Offer / key details: Fibre upgrade eligibility and modem offer
- Compliance notes: None
