# Approved EDM (Copy Extract)

**comm_type:** marketing
**campaign_type:** offer
**product:** mobile
**audience_stage:** onboarding
**date_sent:** 2026-02-10
**source:** sanitised internal HTML example

## Subject
Activate your SIM in minutes

## Preheader
Your Dodo SIM is ready

## Body (rendered text; NO PII)
Hey <FIRSTNAME>

Your Dodo SIM is good to go — all that’s left is to activate. It’s quick, easy, and you’ll unlock great value straight away.

With Dodo mobile you get the Real Deal
- Keep your existing number
- Data banking — keep more of what you don’t use
- No lock-in monthly contract — change your plan anytime through My Dodo
- We bill monthly, not every 28 days

CTA: ACTIVATE NOW

Great value already locked in
Your introductory offer is secured from when you ordered your SIM.

Over 1,300 5-star reviews

## Notes (optional)
- CTA label: ACTIVATE NOW IN MY DODO
- Offer / key details: Introductory offer secured
- Compliance notes: None
