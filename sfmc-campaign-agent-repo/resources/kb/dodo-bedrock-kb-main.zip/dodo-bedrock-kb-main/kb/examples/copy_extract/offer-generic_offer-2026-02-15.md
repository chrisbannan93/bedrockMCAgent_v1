# Approved EDM (Copy Extract)

**comm_type:** marketing
**campaign_type:** offer
**product:** internet
**audience_stage:** prospect
**date_sent:** 2026-02-15
**source:** pending sanitised example

## Subject
Limited-time offer – save big on your next plan

## Preheader
Upgrade today and enjoy 50% off for the first 4 months.

## Body (rendered text; NO PII)
Hi TestUser,
For a limited time, get 50% off selected mobile plans for your first 4 months. Upgrade now and enjoy faster speeds, more data, and unbeatable value. Hurry – offer ends 15 February 2026.

## Notes (optional)
- CTA label: UPGRADE NOW
- Offer / key details: Offer: 50% off selected mobile plans; Eligibility: New and returning customers; Offer End Date: 15 February 2026
- Compliance notes: This is a test promotional message for internal validation.
