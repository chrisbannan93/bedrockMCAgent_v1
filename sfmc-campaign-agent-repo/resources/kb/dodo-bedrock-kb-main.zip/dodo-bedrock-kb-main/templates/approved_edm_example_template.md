﻿# TEMPLATE — Approved EDM (Copy Extract)

**comm_type:** (service|marketing)
**campaign_type:** (service_notice|offer|price_change|billing|outage|winback|other)
**product:** (internet|mobile|energy|other)
**audience_stage:** (prospect|onboarding|active|at-risk|billing|retention)
**date_sent:** (YYYY-MM-DD)
**source:** (internal reference only; do not include PII)

## Subject
...

## Preheader
...

## Body (rendered text; NO PII)
...

## Notes (optional)
- CTA label:
- Offer / key details:
- Compliance notes:
